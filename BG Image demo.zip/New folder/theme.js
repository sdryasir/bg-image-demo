/**
 * @var $ jQuery
 */



/* Document Ready ---------------------- */

$(document).ready(function () {


    // BG from img src...
    $(".carousel-fs .carousel-inner .carousel-item, .bg_from-child").each(function () {
        const imgSrc = $(this).find('img').attr('src');
        $(this).css("background-image", "url('" + imgSrc + "')");
    });





    // Inline background image...
    $("[data-bg]").each(function () {
        const image = $(this).attr("data-bg");
        $(this).css({
            backgroundImage: 'url("' + image + '")',
        });
    });

});

